package com.example.phase2.Plans;

public interface Plan {
	public double getCost();
	public void setCost(double c);
}
