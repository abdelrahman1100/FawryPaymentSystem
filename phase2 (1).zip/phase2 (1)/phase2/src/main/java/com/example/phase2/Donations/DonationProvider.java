package com.example.phase2.Donations;

public interface DonationProvider {
	public void makeDonation(double d);
	public double getDonation();
}
