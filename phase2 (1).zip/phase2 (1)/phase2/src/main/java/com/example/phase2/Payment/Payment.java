package com.example.phase2.Payment;

import com.example.phase2.Services.Service;

public interface Payment {
	public void pay(Service service);
}
