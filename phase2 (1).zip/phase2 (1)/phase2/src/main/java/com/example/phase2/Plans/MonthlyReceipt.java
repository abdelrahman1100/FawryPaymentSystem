package com.example.phase2.Plans;


import java.util.LinkedList;

import com.example.phase2.Discount.DiscountDecorator;
import com.example.phase2.Payment.Payment;
import com.example.phase2.Payment.PaymentFactory;
import com.example.phase2.Services.Landline;
import com.example.phase2.Services.Service;

public class MonthlyReceipt implements Plan {
	
	private double Cost=0;
	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setCost(double c) {
		// TODO Auto-generated method stub
		
	}
	
	

}
